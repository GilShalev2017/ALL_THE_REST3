"use strict";
var express = require("express");
var bodyParser = require("body-parser");
var cors = require('cors');
var app = express();
// var mongoose = require('mongoose');
// mongoose.connect("mongodb://localhost/mydb");
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
//
// /* Update */
// app.put('/api/user/:name', function (req, res) {
//
//     var updatedObject = new User(req.body);
//
//     var query = {_id: updatedObject._id};
//
//     User.update(query, updatedObject, function (err: any, affectedRows: number, raw: any) {
//         if (err) {
//             console.log("in update - user wasn't updated!!!");
//
//             res.json({info: 'error during updating user', error: err});
//         }
//         else {
//             console.log("in update - updated successfully!!!");
//
//             res.json({info: 'User updated successfully', data: req.params});
//         }
//     });
// });
//
//
// /* Delete */
// app.delete('/api/user', function (req, res) {
//
//     console.log("in delete");
//
//     var userToDelete = new User(req.body);
//
//     //var query = {first_name: userToDelete.first_name and last_name: userToDelete.last_name};
//     var query = {_id: userToDelete._id};
//
//     User.remove(query, function (err) {
//
//         if (err) {
//             console.log("in delete - user wasn't removed!!!");
//             res.json({info: 'error during removing user', error: err});
//         }
//         else {
//             res.json({info: 'User removed successfully', data: userToDelete});
//         }
//     });
//
// });
//
// /* Create */
// app.post('/api/user', function (req, res) {
//     console.log("in Post");
//
//     var newUser = new User(req.body);
//     newUser.save((err) => {
//         if (err) {
//             res.json({info: 'error during User create', error: err});
//         }
//         res.json({info: 'User saved successfully', data: newUser});
//     });
// });
//
// /* Read all */
// app.get('/api/user', function (req, res) {
//
//     // console.log("in read all - start");
//
//     User.find((err, Users) => {
//         if (err) {
//             console.log("error");
//             res.json({info: 'error during find Users', error: err});
//         }
//         ;
//
//         res.json({info: 'Users found successfully', data: Users});
//     });
//
//     // console.log("in read all - end");
// });
//
// /* Find one */
// app.get('/api/user/:name', function (req, res) {
//
//     console.log("in find one");
//
//     var query = {first_name: req.params.name};
//
//     User.findOne(query, function (err, User) {
//
//         if (err) {
//             res.json({info: 'error during find User', error: err});
//         }
//         ;
//         if (User) {
//             res.json({info: 'User found successfully', data: User});
//         } else {
//             res.json({info: 'User not found with name:' + req.params.name});
//         }
//     });
// });
// *************** Login ************************
app.post('/api/login', function (req, res) {
    console.log("in Login");
    var username = req.body.username;
    var password = req.body.password;
    //check against DB if password match if yes - return User
    //if not return error message
    // var newUser = new User(req.body);
    // newUser.save((err) => {
    //     if (err) {
    //         res.json({info: 'error during User create', error: err});
    //     }
    var newUser = {
        user: {
            name: username,
            role: "",
            permissions: ["permissions"],
            contact_details: {
                full_name: username,
            }
        },
        token: "112233",
        expiresOn: new Date()
    };
    res.json({ info: 'User is approved', data: newUser });
    //});
});
// @route('POST',
//     '/api/v1/web/login',
//     'login',
//     `login to the server`,
//     ['login'])
// static login(req: H.Request, reply: H.IReply) {
//     if (!req.payload) {
//         reply(Boom.unauthorized('invalid credentials'));
//     }
//     else {
//         let username = req.payload.username;
//         let password = req.payload.password;
//         let ip: String = req.headers['x-real-ip'] || req.info.remoteAddress;
//
//         if (username) {
//             username = username.toLocaleLowerCase().trim();
//         }
//
//
//         let userLoginReq = {
//             url: 'https://api.pickspace.net/api/v1/supply/login',
//             // url: 'http://localhost:3001/api/v1/supply/login',
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Origin': 'https://pickspace.net'
//             },
//             body: JSON.stringify({username: username, password: password})
//         };
//
//         logger.log('info', 'the user: ' + username + ' is trying to login');
//         request(userLoginReq, (error, response, body) => {
//             if (error) {
//                 logger.log('info', 'error occurred while trying to authenticate!');
//                 return reply(Boom.badImplementation(error))
//             }
//             body = JSON.parse(body);
//             if (response.statusCode != 200) {
//                 logger.log(`user doesn't exist on pickboard, checking as TV user`);
//                 SpacebookLoginApi.retriever.getLocationTvUser(username).then((location: SpaceLocation) => {
//                     if(!location){
//                         logger.log('info', 'the user: ' + username + ' is unauthorized!');
//                         return reply(Boom.create(response.statusCode, body.message, body.error));
//                     }
//
//                     SpacebookLoginApi.passModule.comparePassword(password, location.settings.password).then(match => {
//                         if (match) {
//                             logger.log('info', 'the user: ' + username + ' is connected as TV!');
//                             let token = jwt.sign(
//                                 {type: 'TV', username: username, password: password, locationId: location.id},
//                                 process.env.STR_TO_WT || 'test',
//                                 {expiresIn: '30d'}
//                             );
//                             return reply({token:token, TV: true}).state('data', token);
//                         }
//                         reply(Boom.unauthorized('invalid credentials'));
//                     }, err => {
//                         logger.log('info', 'error occurred while trying to authenticate!');
//                         return reply(Boom.badImplementation(err))
//                     })
//                 }, err => {
//                     logger.log('info', 'error occurred while trying to authenticate!');
//                     return reply(Boom.badImplementation(err))
//                 });
//             }
//             else {
//                 logger.log('info', 'the user: ' + username + ' is connected!');
//                 return reply(body).state('data', body.token);
//             }
//         });
//     }
// }
// *************** Dashboard ************************
app.get('/api/dashboard', function (req, res) {
    var dashBoardData = {
        'impressisons': 10877,
        'clicks': 1236,
        'ctr': '11.2%',
        'ecpm': '4.5$',
        'pieChartData1': {
            'pieChartLabels': ['Download Sales', 'In-Store Sales', 'Mail Sales', 'Clicks', 'Impressisons'],
            'pieChartData': [300, 500, 100, 100, 50, 700]
        },
        'pieChartData2': {
            'pieChartLabels': ['Download Sales', 'In-Store Sales', 'Mail Sales'],
            'pieChartData': [300, 500, 100]
        },
        'lineChartData': {
            'lineChartData': [
                { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
                { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
                { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C' },
                { data: [22, 33, 55, 9, 100, 22, 11], label: 'Series E' }
            ], 'lineChartLabels': ['', '', '', '', '', '', '']
        }
    };
    res.json({ info: 'Dashboard data found successfully', data: dashBoardData });
});
// *************** Websites ************************
app.get('/api/websites', function (req, res) {
    var websitesData = [
        {
            'id': '1',
            'website': 'Cnn.com',
            'impressions': 2566,
            'clicks': 189
        },
        {
            'id': '2',
            'website': 'Ynet.co.il',
            'impressions': 3459,
            'clicks': 329
        },
        {
            'id': '3',
            'website': 'tmz.com',
            'impressions': 2566,
            'clicks': 189
        },
        {
            'id': '4',
            'website': 'Forbes.com',
            'impressions': 2566,
            'clicks': 189
        }
    ];
    res.json({ info: 'Dashboard data found successfully', data: websitesData });
});
app.get('/api/websites/:id', function (req, res) {
    var websiteId = req.params.id;
    console.log(websiteId);
    // var website="koko";
    // switch (id)
    // {
    //     case '1':
    //         website = 'Cnn.com';
    //         break;
    //     case '2':
    //         website = 'Ynet.co.il';
    //         break;
    //     case '3':
    //         website = 'tmz.com';
    //         break;
    //     case '4':
    //         website = 'Forbes.com';
    //         break;
    // }
    if (websiteId === '1') {
        var campaignData = [
            {
                'brand': 'Nike',
                'website': 'Cnn.com',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Coca Cola',
                'website': 'Cnn.com',
                'impressions': 3459,
                'clicks': 329
            },
            {
                'brand': 'Lotto',
                'website': 'Cnn.com',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Wix',
                'website': 'Cnn.com',
                'impressions': 2566,
                'clicks': 189
            }
        ];
        return res.json({ info: 'campaign data found successfully', data: campaignData });
    }
    else if (websiteId === '2') {
        var campaignData = [
            {
                'brand': 'Nike',
                'website': 'Ynet.co.il',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Coca Cola',
                'website': 'Ynet.co.il',
                'impressions': 3459,
                'clicks': 329
            },
            {
                'brand': 'Lotto',
                'website': 'Ynet.co.il',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Wix',
                'website': 'Ynet.co.il',
                'impressions': 2566,
                'clicks': 189
            }
        ];
        return res.json({ info: 'campaign data found successfully', data: campaignData });
    }
    else if (websiteId === '3') {
        var campaignData = [
            {
                'brand': 'Nike',
                'website': 'tmz.com',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Coca Cola',
                'website': 'tmz.com',
                'impressions': 3459,
                'clicks': 329
            },
            {
                'brand': 'Lotto',
                'website': 'tmz.com',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Wix',
                'website': 'tmz.com',
                'impressions': 2566,
                'clicks': 189
            }
        ];
        return res.json({ info: 'campaign data found successfully', data: campaignData });
    }
    else {
        var campaignData = [
            {
                'brand': 'Nike',
                'website': 'Forbes.com',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Coca Cola',
                'website': 'Forbes.com',
                'impressions': 3459,
                'clicks': 329
            },
            {
                'brand': 'Lotto',
                'website': 'Forbes.com',
                'impressions': 2566,
                'clicks': 189
            },
            {
                'brand': 'Wix',
                'website': 'Forbes.com',
                'impressions': 2566,
                'clicks': 189
            }
        ];
        return res.json({ info: 'campaign data found successfully', data: campaignData });
    }
});
var server = app.listen(4005, function () {
    console.log('Server listening on port 4005');
});
//# sourceMappingURL=index.js.map