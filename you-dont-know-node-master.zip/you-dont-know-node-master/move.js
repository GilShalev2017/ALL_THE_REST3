// npm install you-dont-know-node -g --prefix .
//mv ./lib/node_modules/you-dont-know-node . && rm -rf ./etc  && rm -rf ./lib"
//https://github.com/npm/npm/issues/4017
