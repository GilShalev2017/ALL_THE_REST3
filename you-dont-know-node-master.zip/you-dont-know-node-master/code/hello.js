// hello.js
var addon = require('./build/Release/addon');

console.log(addon.hello()); // world
