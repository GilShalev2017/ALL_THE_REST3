"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LocalStorageKey;
(function (LocalStorageKey) {
    LocalStorageKey[LocalStorageKey["User"] = 0] = "User";
})(LocalStorageKey = exports.LocalStorageKey || (exports.LocalStorageKey = {}));
// export interface Line {
//     prevPos: { x: number; y: number; };
//     currentPos: { x: number; y: number};
// }
//# sourceMappingURL=app.models.js.map