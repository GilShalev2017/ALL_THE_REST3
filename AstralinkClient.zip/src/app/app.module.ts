// Modules (imports)
import {NgModule}      from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {AppRoutingModule} from './config/app.routing.component';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {BsDropdownModule} from 'ngx-bootstrap';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// Components (declarations)
import {RootComponent}  from './components/root/root.component';
import {DrawingListComponent}  from './components/drawing-list/drawing-list.component';
import {DrawingComponent}  from './components/drawing-canvas/drawing-canvas.component';
import {LoginComponent}  from './components/login/login.component';
import {PageNotFoundComponent}  from './components/page-not-found/page-not-found.component';
// Services (providers)
import {NetService} from './services/net/net.service';
import {DrawingService} from './services/drawing/drawing.service';
import {UserService} from './services/user/user.service';
import {LocalStorageService} from './services/localStorage/localStorage.service';
import {AuthGuard} from './guards/auth-guard';
import {ToastService} from './services/toast/toast.service';

// import 'node_modules/ngx-toast/toast';
// import { ToastrModule } from 'ngx-toast';

@NgModule({
    imports: [BrowserModule, AppRoutingModule, HttpModule, FormsModule,
        // ToastrModule.forRoot(),
        BsDropdownModule.forRoot(),
        // ModalModule.forRoot(),
        // DatepickerModule.forRoot(),
        // TimepickerModule.forRoot(),
        // DatepickerModule.forRoot(),
        ],
    declarations: [RootComponent, DrawingListComponent, DrawingComponent, LoginComponent, PageNotFoundComponent],
    providers: [NetService, DrawingService, UserService, LocalStorageService, ToastService, AuthGuard],
    bootstrap: [RootComponent]
})
export class AppModule {
}
