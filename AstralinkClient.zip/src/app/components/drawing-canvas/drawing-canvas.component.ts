import {AfterViewInit, Component, ViewChild, ElementRef, Input} from '@angular/core';
import {DrawingService} from '../../services/drawing/drawing.service';
// import {Observable} from 'rxjs/Observable';
// import 'rxjs/add/observable/fromEvent';
// import 'rxjs/add/operator/takeUntil';
// import 'rxjs/add/operator/pairwise';
// import 'rxjs/add/operator/switchMap';
import {Drawing, Line, Point} from '../../models/app.models';
import {UserService} from '../../services/user/user.service';
import {ActivatedRoute, Params} from '@angular/router';

import {ToastService} from '../../services/toast/toast.service';

@Component({
    selector: 'drawing',
    templateUrl: './drawing-canvas.component.html'
})

export class DrawingComponent implements AfterViewInit {

    @ViewChild('canvas') public canvas: ElementRef;

    @Input() public width = 1100;
    @Input() public height = 450;

    private cx: CanvasRenderingContext2D;
    startTime: Date;
    endTime: Date;
    drawingTime: Date;
    creationTime: number;
    img: string;
    drawing_id: string;
    selectedColor: string;
    selectedLineWidth: number;
    whatTime: Date;
    recordedLines: Line[];
    clicked: number;
    measuringTimerId: number;
    isRecording: boolean;
    isPlaying: boolean;
    playIntervalId: number;
    prevPosPoint: Point;
    currentPosPoint: Point;

//     this.recordedLines.push(
//     {
//         prevPos: {x: prevPos.x, y: prevPos.y},
// currentPos: {x: currentPos.x, y: currentPos.y}
// });
    constructor(private drawingService: DrawingService,
                private userService: UserService,
                private toast: ToastService,
                private activatedRoute: ActivatedRoute) {
    }

    ngOnInit(): void {

        this.recordedLines = [];
        this.isRecording = null;
        this.isPlaying = null;

        this.activatedRoute.params.forEach((params: Params) => {
            this.drawing_id = params['id'];
        });
    }

    public ngAfterViewInit() {

        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        this.cx = canvasEl.getContext('2d');

        canvasEl.width = this.width;
        canvasEl.height = this.height;

        this.cx.lineWidth = 5;
        this.cx.lineCap = 'round';
        this.cx.strokeStyle = '#000';

        // this.cx.setLineDash([5, 3]);
        // for (let i = 0; i < 6; i++) {
        //     for (let j = 0; j < 6; j++) {
        //         this.cx.strokeStyle = 'rgb(0,' + Math.floor(255 - 42.5 * i) + ',' + Math.floor(255 - 42.5 * j) + ')';
        //     }
        // }
        // this.captureEvents(canvasEl);

        this.addDrawingToCanvas();

        this.selectColor('blue');


        // this.drawTouch();
    }

    touchStart(e) {

        if (!this.startTime) {
            this.startTime = new Date();
            this.creationTime = null;
            this.startMeasuringTimer();
        }

        this.cx.beginPath();

        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        const rect = canvasEl.getBoundingClientRect();

        let x = e.changedTouches[0].pageX - rect.left;
        let y = e.changedTouches[0].pageY - rect.top;

        this.cx.moveTo(x, y);

        if (this.isRecording) {
            this.prevPosPoint = {x: x, y: y};
        }
    }

    touchMove(e) {

        this.endTime = new Date();
        this.creationTime = this.endTime.getTime() - this.startTime.getTime();

        e.preventDefault();

        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        const rect = canvasEl.getBoundingClientRect();

        let x = e.changedTouches[0].pageX - rect.left;
        let y = e.changedTouches[0].pageY - rect.top;

        this.cx.lineTo(x, y);
        this.cx.stroke();

        if (this.isRecording) {
            this.currentPosPoint = {x: x, y: y};
            this.recordedLines.push({
                prevPos: this.prevPosPoint,
                currentPos: this.currentPosPoint,
                color: this.selectedColor,
                lineWidth: this.selectedLineWidth
            });
            this.prevPosPoint = this.currentPosPoint;
        }
    }

    onmousedown(e) {

        if (!this.startTime) {
            this.startTime = new Date();
            this.creationTime = null;
            this.startMeasuringTimer();
        }

        this.clicked = 1;

        this.cx.beginPath();

        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        const rect = canvasEl.getBoundingClientRect();

        let x = e.pageX - rect.left;
        let y = e.pageY - rect.top;
        this.cx.moveTo(x, y);

        if (this.isRecording) {
            this.prevPosPoint = {x: x, y: y};
        }
    }

    onmousemove(e) {
        if (this.clicked) {

            const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
            const rect = canvasEl.getBoundingClientRect();

            let x = e.pageX - rect.left;
            let y = e.pageY - rect.top;
            this.cx.lineTo(x, y);
            this.cx.stroke();

            if (this.isRecording) {
                this.currentPosPoint = {x: x, y: y};
                this.recordedLines.push({
                    prevPos: this.prevPosPoint,
                    currentPos: this.currentPosPoint,
                    color: this.selectedColor,
                    lineWidth: this.selectedLineWidth
                });
                this.prevPosPoint = this.currentPosPoint;
            }
        }
    }

    onmouseup() {
        this.clicked = 0;

        this.endTime = new Date();
        this.creationTime = this.endTime.getTime() - this.startTime.getTime();
    }

    addDrawingToCanvas() {

        if (this.drawing_id) {

            this.drawingService.getDrawing(this.drawing_id).subscribe((drawing: Drawing) => {
                this.img = drawing.data;
                // });

                let paint = new Image();

                paint.src = this.img; // can also be a remote URL e.g. http://

                let _this = this;

                paint.onload = function () {
                    _this.cx.drawImage(paint, 0, 0);
                };
            });
        }
    }

    // private captureEvents(canvasEl: HTMLCanvasElement) {
    //     Observable
    //         .fromEvent(canvasEl, 'mousedown')
    //         .switchMap((e) => {
    //             return Observable
    //                 .fromEvent(canvasEl, 'mousemove')
    //                 .takeUntil(Observable.fromEvent(canvasEl, 'mouseup'))
    //                 .pairwise();
    //         })
    //         .subscribe((res: [MouseEvent, MouseEvent]) => {
    //
    //             if (!this.startTime) {
    //                 this.startTime = new Date();
    //             }
    //
    //             this.endTime = new Date();
    //
    //             const rect = canvasEl.getBoundingClientRect();
    //
    //             const prevPos = {
    //                 x: res[0].clientX - rect.left,
    //                 y: res[0].clientY - rect.top
    //             };
    //
    //             const currentPos = {
    //                 x: res[1].clientX - rect.left,
    //                 y: res[1].clientY - rect.top
    //             };
    //
    //             this.drawOnCanvas(prevPos, currentPos);
    //         });
    // }

    // private drawOnCanvas(prevPos: { x: number, y: number }, currentPos: { x: number, y: number }) {
    //     if (!this.cx) {
    //         return;
    //     }
    //
    //     this.cx.beginPath();
    //
    //     if (prevPos) {
    //         this.cx.moveTo(prevPos.x, prevPos.y); // from
    //         this.cx.lineTo(currentPos.x, currentPos.y);
    //         this.cx.stroke();
    //
    //         this.recordedLines.push(
    //             {
    //                 prevPos: {x: prevPos.x, y: prevPos.y},
    //                 currentPos: {x: currentPos.x, y: currentPos.y}
    //             });
    //     }
    // }

    newCanvas() {
        this.cx.clearRect(0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.height);
        window.clearInterval(this.measuringTimerId);
        this.startTime = null;
    }

    saveDrawing() {

        // this.creationTime = this.endTime.getTime() - this.startTime.getTime();
        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        let dataURL = canvasEl.toDataURL('image/png', 1.0);

        let drawing: Drawing = {
            created_by: this.userService.getLoggedInUser().name,
            creation_date_time: this.startTime.toString(),
            drawing_time: this.creationTime.toString(),
            data: dataURL
        };

        this.drawingService.uploadDrawing(drawing).subscribe((arrivedData: Drawing) => {
            this.toast.success('your painting hab been successfuly uploaded to the server.');
        });

        this.startTime = null;
        window.clearInterval(this.measuringTimerId);
    }

    startMeasuringTimer() {
        this.measuringTimerId = window.setInterval(() => {
            let currentTimeMilli: number = new Date().getTime();
            let startTimeMilli: number = this.startTime.getTime();
            this.drawingTime = new Date(currentTimeMilli - startTimeMilli);
            // console.log(currentTimeMilli);
            // console.log(startTimeMilli);
        }, 1000);
    }

    selectErase() {
        this.selectColor('white');
    }

    isSelectedColor(color: string): boolean {
        return color === this.selectedColor ? true : false;
    }

    selectColor(color: string) {
        this.cx.strokeStyle = color;
        this.selectedColor = color;
    }

    increaseLineSize(size: number) {
        this.cx.lineWidth += 2;
        this.selectedLineWidth = this.cx.lineWidth;
    }

    decreaseLineSize(size: number) {
        this.cx.lineWidth -= 2;
        this.selectedLineWidth = this.cx.lineWidth;
    }

    record() {
        this.isRecording = true;
    }

    stopRecordingOrPlaying() {
        if (this.isPlaying) {
            this.stopPlaying();
        }
        this.isRecording = false;
        this.isPlaying = false;
    }

    stopPlaying() {
        window.clearInterval(this.playIntervalId);
        this.isPlaying = false;
    }

    clearRecord() {
        this.newCanvas();
        this.recordedLines = [];
    }

    play() {
        this.newCanvas();

        this.isPlaying = true;

        // console.log(this.recordedLines);

        let index = 0;

        let _this = this;

        this.playIntervalId = window.setInterval(() => {

            if (index === this.recordedLines.length) {
                _this.stopPlaying();
                return;
            }

            if (_this.recordedLines[index].prevPos && _this.recordedLines[index].currentPos) {

                _this.drawLine(_this.recordedLines[index]);

                index++;
            }
        }, 50);
    }

    private drawLine(line: Line) {
        if (!this.cx) {
            return;
        }

        this.cx.beginPath();

        if (line) {
            this.cx.strokeStyle = line.color;
            this.cx.lineWidth = line.lineWidth;
            this.cx.moveTo(line.prevPos.x, line.prevPos.y); // from
            this.cx.lineTo(line.currentPos.x, line.currentPos.y);
            this.cx.stroke();
        }
    }
}
