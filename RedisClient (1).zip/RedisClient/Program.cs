﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using StackExchange.Redis;
namespace RedisClient
{
    class Program
    {
        static void Main(string[] args)
        {         

            ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(args[0]);
            IDatabase db = redis.GetDatabase();
            //Console.WriteLine("Connected:  " + db.IsConnected());
            db.KeyDelete("pcam1");
           
            //  Create a sorted set and populate with sample data, skip the values 12,17 and 18 to simulate missing frames
            for (int k = 0; k < 20; k++)
            {
                if (k == 12 || k == 17 || k == 18)
                    continue;

                db.SortedSetAdd("pcam1", k, k);
            }
            
            var pcam1Values = db.SortedSetRangeByRank("pcam1");
            var arrayOfRanges = getFrameRanges(pcam1Values);
            dynamic frameRangesJson = new JObject();
            frameRangesJson.frames = arrayOfRanges;
            string x = frameRangesJson.ToString();
            Console.WriteLine(x);
            
        }

        public static JArray getFrameRanges(RedisValue[] pcamValues)
        {
            JArray arrayOfRanges = new JArray();

            if (pcamValues.Length == 0)
                return arrayOfRanges;            

            int index = 0;
            int length = pcamValues.Length;
            int startRange = (int)pcamValues[0];            
            List<int> ranges = new List<int>();
           
            while (index < length)
            {
                if ((index + 1) < length && ((int)(pcamValues[index]) + 1) == (int)pcamValues[index + 1])
                {
                    index++;
                    continue;
                }
                else
                {         
                    // Add to a json array
                    JArray singleFrameRange = new JArray();
                    singleFrameRange.Add(startRange);
                    singleFrameRange.Add((int)pcamValues[index]);
                    arrayOfRanges.Add(singleFrameRange);

                    //  Set the next start range
                    if ((index + 1) < length)
                    {
                        startRange = (int)pcamValues[index + 1];
                    }
                }

                index++;
            }           
           
            return arrayOfRanges;
        }
    }
}
