"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//
// export interface User {
//     user: {
//         name: string;
//         // role: string;
//         // permissions: string[];
//         // contact_details: {
//         //     full_name: string;
//         // }
//     };
//     token: string;
//     expiresOn: Date;
// }
var LocalStorageKey;
(function (LocalStorageKey) {
    LocalStorageKey[LocalStorageKey["User"] = 0] = "User";
})(LocalStorageKey = exports.LocalStorageKey || (exports.LocalStorageKey = {}));
//# sourceMappingURL=app.models.js.map