import { Component } from '@angular/core';
import {DashboardService} from '../../services/dashboard/dashboard.service';
import {DashboardData} from '../../models/app.models';

@Component({
    selector: 'dashboard',
    templateUrl: './dashboard.component.html'
})
export class DashboardComponent {

    dashboardData : DashboardData;

    // // lineChart
    // public lineChartData: Array<any> = [
    //     {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
    //     {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
    //     {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'},
    //     {data: [22, 33, 55, 9, 100, 22, 11], label: 'Series E'}
    // ];
    // public lineChartLabels: Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
    public lineChartLabels: Array<any> = ['', '', '', '', '', '', ''];
    public lineChartOptions: any = {
        responsive: true
    };
    public lineChartColors: Array<any> = [
        { // grey
            backgroundColor: 'rgba(148,159,177,0.2)',
            borderColor: 'rgba(148,159,177,1)',
            pointBackgroundColor: 'rgba(148,159,177,1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        },
        { // dark grey
            backgroundColor: 'rgba(77,83,96,0.2)',
            borderColor: 'rgba(77,83,96,1)',
            pointBackgroundColor: 'rgba(77,83,96,1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(77,83,96,1)'
        },
        { // grey
            backgroundColor: 'rgba(148,159,177,0.2)',
            borderColor: 'rgba(148,159,177,1)',
            pointBackgroundColor: 'rgba(148,159,177,1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }
    ];
    public lineChartLegend: boolean = true;
    public lineChartType: string = 'line';
    public pieChartType:string = 'pie';

    // Pie
    // public pieChartLabels:string[] = ['Download Sales', 'In-Store Sales', 'Mail Sales'];
    // public pieChartData:number[] = [300, 500, 100, 100, 50, 700];

    constructor(private dashboardService : DashboardService) {
    }

    ngOnInit(): void {
        this.dashboardService.getDashboardData().subscribe((arrivedData: DashboardData) => {
            this.dashboardData = arrivedData;

            this.drawPieChart();
        });
    }

    drawPieChart() {

        var data:any = [];

        google.charts.load('current', {'packages': ['corechart']});

        data.push(['Task', 'Hours per Day']);

        var innerArray = ["catgeory1", 500];
        data.push(innerArray);
        var innerArray = ["catgeory2", 200];
        data.push(innerArray);
        var innerArray = ["catgeory3", 600];
        data.push(innerArray);
        var innerArray = ["catgeory4", 100];
        data.push(innerArray);

        google.charts.setOnLoadCallback(()=>this.drawChart(data));

        google.charts.setOnLoadCallback(()=>this.drawChart2());
    }

    drawChart2() {

        var data = google.visualization.arrayToDataTable([
            ['Task', 'Hours per Day'],
            ['Work', 11],
            ['Eat', 2],
            ['Commute', 2],
            ['Watch TV', 2],
            ['Sleep', 7]
        ]);

        var options = {
            title: 'My Daily Activities'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart2'));

        chart.draw(data, options);
    }

    drawChart(dataRaw:any) {

        var data = google.visualization.arrayToDataTable(dataRaw);

        var options = {
            title: 'My Expenses',
            pieHole: 0.4,
            is3D: true,
            backgroundColor: 'transparent',
            legend: {textStyle: {color: 'white', fontSize: 12}},
            titleTextStyle : { color: 'white'}
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart1'));

        chart.draw(data, options);

        // let chart2 = new google.visualization.PieChart(document.getElementById('piechart2'));
        //
        // chart2.draw(data, options);
    }
}
