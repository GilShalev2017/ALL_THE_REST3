import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './root.component.html'
})
export class RootComponent { name = 'Angular'; }
