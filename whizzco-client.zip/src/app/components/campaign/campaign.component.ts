import {Component} from '@angular/core';
import {CampaignService} from '../../services/campaign/campaign.service';
import {CampaignData} from '../../models/app.models';
import {ActivatedRoute, Params} from "@angular/router";

@Component({
    selector: 'campaign',
    templateUrl: './campaign.component.html'
})

export class CampaignComponent {
    campaignData: CampaignData[];

    constructor(private campaignService: CampaignService,
                private activatedRoute: ActivatedRoute) {
    }

    ngOnInit(): void {

        this.activatedRoute.params.forEach((params: Params) => {
            let websiteId = params['name'];

            this.campaignService.getCampaignData(websiteId).subscribe((arrivedData: CampaignData[]) => {
                this.campaignData = arrivedData;
            });
        });
    }
}
