import { Component } from '@angular/core';
import { WebsitesService } from '../../services/websites/websites.service';
import { WebsiteData } from '../../models/app.models';

@Component({
    selector: 'websites',
    templateUrl: './websites.component.html'
})
export class WebsitesComponent {
    websitesData : WebsiteData[];

    constructor(private websitesService : WebsitesService) {
    }

    ngOnInit(): void {
        this.websitesService.getWebsitesData().subscribe((arrivedData: WebsiteData[]) => {
            this.websitesData = arrivedData;
        });
    }
}

