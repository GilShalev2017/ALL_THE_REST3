import {Component, OnInit} from '@angular/core';
import {MashovService} from '../../services/mashov/mashov.service';
import {School, Student} from '../../models/app.models';
import {TranslateService} from '../../translate/translate.service';

@Component({
    moduleId: module.id,
    selector: 'main',
    templateUrl: './main.component.html'
})

export class MainComponent implements OnInit {
    private _selectedSchoolObject: School;
    private _selectedYear: number;
    schoolNames: string[];
    students: Student[];
    filteredStudents: Student[];
    schools: School[];
    public supportedLanguages: any[];
    private _classFilter: string;
    searchString: string;
    imgUrl: string;
    imgUrl1: string = '../../assets/images/brand_1.png';
    imgUrl2: string = '../../assets/images/brand_2.png';

    constructor(private mashovService: MashovService,
                private _translate: TranslateService) {
    }

    get selectedSchoolObject(): School {
        return this._selectedSchoolObject;
    }

    set selectedSchoolObject(value: School) {
        this._selectedSchoolObject = value;
        this.students = null;
        this.filteredStudents = null;
    }

    get selectedYear(): number {
        return this._selectedYear;
    }

    set selectedYear(value: number) {
        this._selectedYear = value;
        if (this._selectedYear) {
            this.mashovService.getStudents(this._selectedSchoolObject.semel, value).subscribe(arrivedData => {
                this.students = arrivedData;
                this.filteredStudents = this.students;
            });
        }
    }

    search() {
        this.filteredStudents = this.students.filter(student =>
        (student.classCode && student.classCode.includes(this.searchString)) ||
        (student.classNum && student.classNum.toString().includes(this.searchString)) ||
        student.fullName.includes(this.searchString) ||
        student.studentId.toString().includes(this.searchString));
    }

    get classFilter(): string {
        return this._classFilter;
    }

    set classFilter(value: string) {
        this._classFilter = value;
        this.runFilters();
    }

    private runFilters(): void {

        if (this._classFilter) {
            this.filteredStudents = this.students.filter(student => student.classCode === this._classFilter);
        } else {
            this.filteredStudents = this.students;
        }
    }

    stopEvents($event, stopPropogation = true, preventDefault = true) {
        if (preventDefault) {
            $event.preventDefault();
        }
        if (stopPropogation) {
            $event.stopPropagation();
        }
    }

    ngOnInit(): void {

        this.imgUrl = this.imgUrl1;
        this.selectLang('he');

        this.mashovService.getSchools().subscribe(arrivedData => {
            // this.data = arrivedData;
            this.schools = arrivedData;
        });
    }

    selectLang(lang: string) {
        // set default;
        this._translate.use(lang);
        // this.refreshText();
    }

    onChange() {
        this.students = null;
        this.selectedYear = null;
    }

    sortTable() {
        let table, rows, switching, i, x, y, shouldSwitch;
        table = document.getElementById('myTable');
        switching = true;
        /*Make a loop that will continue until
         no switching has been done:*/
        while (switching) {
            //start by saying: no switching is done:
            switching = false;
            rows = table.getElementsByTagName('TR');
            /*Loop through all table rows (except the
             first, which contains table headers):*/
            for (i = 0; i < (rows.length - 1); i++) {
                //start by saying there should be no switching:
                shouldSwitch = false;
                /*Get the two elements you want to compare,
                 one from current row and one from the next:*/
                x = rows[i].getElementsByTagName('TD')[3];
                y = rows[i + 1].getElementsByTagName('TD')[3];
                //check if the two rows should switch place:
                if (parseInt(x.innerHTML.toLowerCase()) > parseInt(y.innerHTML.toLowerCase())) {
                    //if so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            }
            if (shouldSwitch) {
                /*If a switch has been marked, make the switch
                 and mark that a switch has been done:*/
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
            }
        }
    }

    changeImage() {
        if (this.imgUrl !== this.imgUrl1) {
            this.imgUrl = this.imgUrl1;
        } else {
            this.imgUrl = this.imgUrl2;
        }
    }
}
