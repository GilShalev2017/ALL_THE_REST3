"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const mashov_service_1 = require("../../services/mashov/mashov.service");
const translate_service_1 = require("../../translate/translate.service");
let MainComponent = class MainComponent {
    constructor(mashovService, _translate) {
        this.mashovService = mashovService;
        this._translate = _translate;
        this.imgUrl1 = '../../assets/images/brand_1.png';
        this.imgUrl2 = '../../assets/images/brand_2.png';
    }
    get selectedSchoolObject() {
        return this._selectedSchoolObject;
    }
    set selectedSchoolObject(value) {
        this._selectedSchoolObject = value;
        this.students = null;
        this.filteredStudents = null;
    }
    get selectedYear() {
        return this._selectedYear;
    }
    set selectedYear(value) {
        this._selectedYear = value;
        if (this._selectedYear) {
            this.mashovService.getStudents(this._selectedSchoolObject.semel, value).subscribe(arrivedData => {
                this.students = arrivedData;
                this.filteredStudents = this.students;
            });
        }
    }
    search() {
        this.filteredStudents = this.students.filter(student => (student.classCode && student.classCode.includes(this.searchString)) ||
            (student.classNum && student.classNum.toString().includes(this.searchString)) ||
            student.fullName.includes(this.searchString) ||
            student.studentId.toString().includes(this.searchString));
    }
    get classFilter() {
        return this._classFilter;
    }
    set classFilter(value) {
        this._classFilter = value;
        this.runFilters();
    }
    runFilters() {
        if (this._classFilter) {
            this.filteredStudents = this.students.filter(student => student.classCode === this._classFilter);
        }
        else {
            this.filteredStudents = this.students;
        }
    }
    stopEvents($event, stopPropogation = true, preventDefault = true) {
        if (preventDefault) {
            $event.preventDefault();
        }
        if (stopPropogation) {
            $event.stopPropagation();
        }
    }
    ngOnInit() {
        this.imgUrl = this.imgUrl1;
        this.selectLang('he');
        this.mashovService.getSchools().subscribe(arrivedData => {
            // this.data = arrivedData;
            this.schools = arrivedData;
        });
    }
    selectLang(lang) {
        // set default;
        this._translate.use(lang);
        // this.refreshText();
    }
    onChange() {
        this.students = null;
        this.selectedYear = null;
    }
    sortTable() {
        let table, rows, switching, i, x, y, shouldSwitch;
        table = document.getElementById('myTable');
        switching = true;
        /*Make a loop that will continue until
         no switching has been done:*/
        while (switching) {
            //start by saying: no switching is done:
            switching = false;
            rows = table.getElementsByTagName('TR');
            /*Loop through all table rows (except the
             first, which contains table headers):*/
            for (i = 0; i < (rows.length - 1); i++) {
                //start by saying there should be no switching:
                shouldSwitch = false;
                /*Get the two elements you want to compare,
                 one from current row and one from the next:*/
                x = rows[i].getElementsByTagName('TD')[3];
                y = rows[i + 1].getElementsByTagName('TD')[3];
                //check if the two rows should switch place:
                if (parseInt(x.innerHTML.toLowerCase()) > parseInt(y.innerHTML.toLowerCase())) {
                    //if so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            }
            if (shouldSwitch) {
                /*If a switch has been marked, make the switch
                 and mark that a switch has been done:*/
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
            }
        }
    }
    changeImage() {
        if (this.imgUrl !== this.imgUrl1) {
            this.imgUrl = this.imgUrl1;
        }
        else {
            this.imgUrl = this.imgUrl2;
        }
    }
};
MainComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'main',
        templateUrl: './main.component.html'
    }),
    __metadata("design:paramtypes", [mashov_service_1.MashovService,
        translate_service_1.TranslateService])
], MainComponent);
exports.MainComponent = MainComponent;
//# sourceMappingURL=main.component.js.map