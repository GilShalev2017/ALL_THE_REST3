// Modules (imports)
import {NgModule}      from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {BsDropdownModule} from 'ngx-bootstrap';
import {Ng2CompleterModule} from 'ng2-completer';

// Components (declarations)
import {MainComponent}  from './components/main/main.component';

// Services (providers)
import {MashovService} from './services/mashov/mashov.service';

import {TRANSLATION_PROVIDERS}  from './translate/translations';
import {TranslatePipe}  from './translate/translate.pipe';
import {TranslateService}  from './translate/translate.service';

export function ng2CompleterModule() {
    return Ng2CompleterModule;
}

@NgModule({
    imports: [BrowserModule, HttpModule, FormsModule, BsDropdownModule.forRoot(), Ng2CompleterModule],
    declarations: [MainComponent, TranslatePipe],
    providers: [MashovService, TRANSLATION_PROVIDERS, TranslateService],
    bootstrap: [MainComponent]
})
export class AppModule {
}
