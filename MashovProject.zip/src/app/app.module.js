"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Modules (imports)
const core_1 = require("@angular/core");
const platform_browser_1 = require("@angular/platform-browser");
const http_1 = require("@angular/http");
const forms_1 = require("@angular/forms");
const ngx_bootstrap_1 = require("ngx-bootstrap");
const ng2_completer_1 = require("ng2-completer");
// Components (declarations)
const main_component_1 = require("./components/main/main.component");
// Services (providers)
const mashov_service_1 = require("./services/mashov/mashov.service");
const translations_1 = require("./translate/translations");
const translate_pipe_1 = require("./translate/translate.pipe");
const translate_service_1 = require("./translate/translate.service");
function ng2CompleterModule() {
    return ng2_completer_1.Ng2CompleterModule;
}
exports.ng2CompleterModule = ng2CompleterModule;
let AppModule = class AppModule {
};
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule, forms_1.FormsModule, ngx_bootstrap_1.BsDropdownModule.forRoot(), ng2_completer_1.Ng2CompleterModule],
        declarations: [main_component_1.MainComponent, translate_pipe_1.TranslatePipe],
        providers: [mashov_service_1.MashovService, translations_1.TRANSLATION_PROVIDERS, translate_service_1.TranslateService],
        bootstrap: [main_component_1.MainComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map