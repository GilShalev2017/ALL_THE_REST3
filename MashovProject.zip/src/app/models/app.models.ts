export interface Student {
    studentId: number;
    fullName: string;
    classCode: string;
    classNum: number;
}

export interface School {
    semel: number;
    name: string;
    years?: number[];
}
