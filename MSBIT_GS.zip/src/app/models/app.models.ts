export interface Book {
    id?: string;
    autuor?: string;
    authorRef?: string;
    date?: Date;
    title?: string;
    image?: string;
}

export interface Box {
    title: string;
    description: string;
}

export interface UiBox {
    id: string;
    name: string;
    category: string;
    img: string;
}
