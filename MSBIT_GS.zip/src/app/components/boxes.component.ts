import {Component, OnInit, TemplateRef} from '@angular/core';
import {Box, UiBox} from '../models/app.models';
import {BoxesService} from '../services/boxes.service';

@Component({
    selector: 'boxes',
    templateUrl: './boxes.component.html',
    styleUrls: ['./boxes.component.css']
})
export class BoxesComponent implements OnInit {

    boxes: Box[];
    uiBoxes: UiBox[];
    filteredUiBoxes: UiBox[];

    constructor(private boxesService: BoxesService) {
    }

    ngOnInit() {
        this.boxesService.getBoxes().subscribe(boxes => {
            this.boxes = boxes;
            this.createUiBoxes();
        });
    }

    createUiBoxes() {
        this.uiBoxes = [];

        for (let box of this.boxes)
        {
            const features = box.title.split(';');
            const imgId = features[1].replace('Box -', '').trim();

                let newUiBox: UiBox = {
                id: '111',
                name: features[1],
                category: features[0],
                img: `../../assets/images/portfolio-${imgId}-sm.jpg`
            };

            this.uiBoxes.push(newUiBox);
        }

        this.filteredUiBoxes = this.uiBoxes.splice(0, 9);
    }

    loadMore() {
        this.filteredUiBoxes = this.uiBoxes;
    }

    filter (category: string) {
        this.filteredUiBoxes = this.uiBoxes.filter(x => x.category.toLowerCase() === category.toLowerCase());
    }

    showAll() {
        this.filteredUiBoxes = this.uiBoxes;
    }
}
