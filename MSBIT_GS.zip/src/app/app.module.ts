import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { ModalModule  } from 'ngx-bootstrap';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './components/app.component';
import { BoxesComponent } from './components/boxes.component';
import { BoxComponent } from './components/box.component';

import { BooksService } from './services/books.service';
import { BoxesService } from './services/boxes.service';

import { TitleCasePipe } from './pipes/title-case.pipe';
import { EnglishLettersPipe } from './pipes/english-letters.pipe';



@NgModule({
  declarations: [
    AppComponent, EnglishLettersPipe, BoxesComponent, BoxComponent
  ],
  imports: [
    BrowserModule, HttpModule, FormsModule, ModalModule.forRoot()
  ],
  providers: [BooksService, BoxesService, TitleCasePipe, EnglishLettersPipe],
  bootstrap: [BoxesComponent]
})
export class AppModule { }
