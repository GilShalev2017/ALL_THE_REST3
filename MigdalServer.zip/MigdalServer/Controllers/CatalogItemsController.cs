﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;
using MigdalServer.Models;

namespace MigdalServer.Controllers
{
    [EnableCors(origins: "http://localhost:3000", headers: "*", methods: "*")]
    public class CatalogItemsController : ApiController
    {
        private MigdalServerContext db = new MigdalServerContext();

        // GET: api/CatalogItems
        public IQueryable<CatalogItem> GetCatalogItems()
        {
            return db.CatalogItems;
        }

        // GET: api/CatalogItems/5
        [ResponseType(typeof(CatalogItem))]
        public IHttpActionResult GetCatalogItem(int id)
        {
            CatalogItem catalogItem = db.CatalogItems.Find(id);
            if (catalogItem == null)
            {
                return NotFound();
            }

            return Ok(catalogItem);
        }

        // PUT: api/CatalogItems/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCatalogItem(int id, CatalogItem catalogItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != catalogItem.ID)
            {
                return BadRequest();
            }

            db.Entry(catalogItem).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CatalogItemExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/CatalogItems
        [ResponseType(typeof(CatalogItem))]
        public IHttpActionResult PostCatalogItem(CatalogItem catalogItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.CatalogItems.Add(catalogItem);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = catalogItem.ID }, catalogItem);
        }

        // DELETE: api/CatalogItems/5
        [ResponseType(typeof(CatalogItem))]
        public IHttpActionResult DeleteCatalogItem(int id)
        {
            CatalogItem catalogItem = db.CatalogItems.Find(id);
            if (catalogItem == null)
            {
                return NotFound();
            }

            db.CatalogItems.Remove(catalogItem);
            db.SaveChanges();

            return Ok(catalogItem);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CatalogItemExists(int id)
        {
            return db.CatalogItems.Count(e => e.ID == id) > 0;
        }
    }
}